# $Id: config_base.sh 1853 2010-03-24 03:06:21Z dub $
tclk=2
sim_cycles=10000
warmup_cycles=100
initial_seed=0
reset_type=1
output_as_csv=1
