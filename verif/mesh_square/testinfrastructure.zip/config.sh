# $Id: config.sh 1853 2010-03-24 03:06:21Z dub $
buffer_occupancy=75
num_ports=10
num_vcs=8
